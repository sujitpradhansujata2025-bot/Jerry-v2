# Jerry Assistant v2

Jerry is a starter Android AI assistant with voice input, spoken replies, Gemini 3.8 Flash, and a small set of local Android actions.

## Included
- Tap-to-talk speech recognition
- Text-to-speech replies
- Gemini 3.8 Flash through the Gemini REST API
- Local API-key storage
- Open common apps: YouTube, WhatsApp, Chrome, Instagram, Maps, Spotify, Settings
- Open the alarm screen
- Dial a phone number after confirmation
- Open the SMS composer
- Google web search

## Important
This version intentionally uses **tap-to-talk**, not a permanent wake-word listener. Android background microphone restrictions vary by device and version; a true "Hey Jerry" implementation needs a foreground service and careful battery/permission handling.

The Gemini API key is stored locally in app preferences. Do not distribute a production APK containing a shared private key. For a public release, put the Gemini API behind your own authenticated backend.

## Build
Open the `JerryAssistant` folder in a compatible Android/Gradle environment and run:

`./gradlew assembleDebug`

The debug APK will be generated at:

`app/build/outputs/apk/debug/app-debug.apk`

Google's current Gemini documentation lists `gemini-3.8-flash` and recommends the Interactions API for new agentic applications; this mobile starter uses the simpler REST `generateContent` call for single-turn responses. See the official docs before production deployment.
