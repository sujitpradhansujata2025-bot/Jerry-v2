package com.jerry.assistant

import android.Manifest
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.AlarmClock
import android.speech.*
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.*
import okhttp3.*
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

private const val PREFS = "jerry_prefs"
private const val KEY_API = "gemini_api_key"
private const val MODEL = "gemini-3.8-flash"

data class Chat(val who: String, val text: String)

class JerryViewModel : ViewModel() {
    var messages by mutableStateOf(listOf(Chat("Jerry", "Hi! I'm Jerry. Tap the microphone and tell me what you need.")))
        private set
    var listening by mutableStateOf(false)
    var thinking by mutableStateOf(false)

    fun addUser(text: String) { messages = messages + Chat("You", text) }
    fun addJerry(text: String) { messages = messages + Chat("Jerry", text) }

    fun askGemini(apiKey: String, prompt: String, onDone: (String) -> Unit) {
        thinking = true
        addUser(prompt)
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val body = JSONObject()
                    .put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", "You are Jerry, a concise, friendly Android voice assistant. Keep answers useful and fairly short. The app executes only supported local actions."))))
                    .put("contents", JSONArray().put(JSONObject()
                        .put("role", "user")
                        .put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
                    .put("generationConfig", JSONObject().put("temperature", 0.7).put("maxOutputTokens", 700))
                    .toString()

                val request = Request.Builder()
                    .url("https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent")
                    .addHeader("x-goog-api-key", apiKey.trim())
                    .addHeader("Content-Type", "application/json")
                    .post(body.toRequestBody("application/json".toMediaType()))
                    .build()

                OkHttpClient().newCall(request).execute().use { response ->
                    val raw = response.body?.string().orEmpty()
                    if (!response.isSuccessful) throw Exception("Gemini HTTP ${response.code}: $raw")
                    val json = JSONObject(raw)
                    val candidates = json.optJSONArray("candidates")
                    val answer = candidates?.optJSONObject(0)
                        ?.optJSONObject("content")
                        ?.optJSONArray("parts")
                        ?.optJSONObject(0)
                        ?.optString("text")
                        ?.takeIf { it.isNotBlank() }
                        ?: "I couldn't generate a response."
                    withContext(Dispatchers.Main) {
                        thinking = false
                        addJerry(answer)
                        onDone(answer)
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    thinking = false
                    val msg = "I couldn't connect to Gemini. Check your API key and internet connection."
                    addJerry(msg)
                    onDone(msg)
                }
            }
        }
    }
}

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var recognizer: SpeechRecognizer? = null
    private var apiKey by mutableStateOf("")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        apiKey = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_API, "").orEmpty()
        tts = TextToSpeech(this, this)
        setContent { JerryApp() }
    }

    @Composable
    private fun JerryApp(vm: JerryViewModel = viewModel()) {
        var showSettings by remember { mutableStateOf(false) }
        var keyInput by remember(apiKey, showSettings) { mutableStateOf(apiKey) }
        var pendingAction by remember { mutableStateOf<(() -> Unit)?>(null) }
        var confirmationText by remember { mutableStateOf("") }

        val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startListening(vm)
        }

        MaterialTheme(colorScheme = darkColorScheme()) {
            Surface(Modifier.fillMaxSize()) {
                Column(Modifier.fillMaxSize().padding(16.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("JERRY", style = MaterialTheme.typography.headlineLarge)
                            Text(if (vm.listening) "Listening…" else if (vm.thinking) "Thinking…" else "Your Android AI assistant")
                        }
                        TextButton(onClick = { showSettings = true }) { Text("Settings") }
                    }
                    Spacer(Modifier.height(12.dp))
                    LazyColumn(Modifier.weight(1f)) {
                        items(vm.messages) { chat ->
                            Text("${chat.who}: ${chat.text}", modifier = Modifier.padding(vertical = 8.dp))
                        }
                    }
                    Button(
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !vm.thinking,
                        onClick = {
                            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                                micPermission.launch(Manifest.permission.RECORD_AUDIO)
                            } else startListening(vm)
                        }
                    ) { Text(if (vm.listening) "Listening…" else "🎙  Talk to Jerry") }
                }
            }

            if (showSettings) {
                AlertDialog(
                    onDismissRequest = { showSettings = false },
                    title = { Text("Jerry Settings") },
                    text = {
                        Column {
                            OutlinedTextField(
                                value = keyInput,
                                onValueChange = { keyInput = it },
                                label = { Text("Gemini API key") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(Modifier.height(8.dp))
                            Text("The key is stored locally on this phone. For a public app, use a backend instead of shipping a private key in the APK.")
                        }
                    },
                    confirmButton = {
                        TextButton(onClick = {
                            apiKey = keyInput.trim()
                            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_API, apiKey).apply()
                            showSettings = false
                        }) { Text("Save") }
                    },
                    dismissButton = { TextButton(onClick = { showSettings = false }) { Text("Cancel") } }
                )
            }

            if (pendingAction != null) {
                AlertDialog(
                    onDismissRequest = { pendingAction = null },
                    title = { Text("Confirm action") },
                    text = { Text(confirmationText) },
                    confirmButton = { TextButton(onClick = { pendingAction?.invoke(); pendingAction = null }) { Text("Confirm") } },
                    dismissButton = { TextButton(onClick = { pendingAction = null }) { Text("Cancel") } }
                )
            }
        }
    }

    private fun startListening(vm: JerryViewModel) {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            vm.addJerry("Speech recognition is not available on this phone.")
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { vm.listening = true }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() { vm.listening = false }
                override fun onError(error: Int) { vm.listening = false; vm.addJerry("I couldn't hear you. Please try again.") }
                override fun onResults(results: Bundle?) {
                    vm.listening = false
                    val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.trim()
                    if (!text.isNullOrBlank()) handleCommand(vm, text)
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            }
            startListening(intent)
        }
    }

    private fun handleCommand(vm: JerryViewModel, text: String) {
        val lower = text.lowercase(Locale.getDefault())
        when {
            lower.startsWith("open ") -> {
                val target = lower.removePrefix("open ").trim()
                val pkg = when {
                    target.contains("youtube") -> "com.google.android.youtube"
                    target.contains("whatsapp") -> "com.whatsapp"
                    target.contains("chrome") -> "com.android.chrome"
                    target.contains("instagram") -> "com.instagram.android"
                    target.contains("maps") -> "com.google.android.apps.maps"
                    target.contains("spotify") -> "com.spotify.music"
                    target.contains("settings") -> null
                    else -> ""
                }
                vm.addUser(text)
                try {
                    val intent = if (target.contains("settings")) Intent(android.provider.Settings.ACTION_SETTINGS)
                    else packageManager.getLaunchIntentForPackage(pkg)
                    if (intent != null) {
                        startActivity(intent)
                        vm.addJerry("Opening $target.")
                        speak("Opening $target")
                    } else {
                        vm.addJerry("I couldn't find that app on your phone.")
                        speak("I couldn't find that app")
                    }
                } catch (_: Exception) {
                    vm.addJerry("I couldn't open that app.")
                    speak("I couldn't open that app")
                }
            }
            lower.contains("set an alarm") || lower.contains("set alarm") -> {
                vm.addUser(text)
                val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                    putExtra(AlarmClock.EXTRA_MESSAGE, "Jerry alarm")
                }
                if (intent.resolveActivity(packageManager) != null) {
                    startActivity(intent)
                    vm.addJerry("Opening the alarm screen so you can choose the time.")
                    speak("Opening the alarm screen")
                } else vm.addJerry("Your phone doesn't provide an alarm app I can open.")
            }
            lower.startsWith("call ") -> {
                val number = text.substringAfter("call ", "").trim()
                vm.addUser(text)
                vm.addJerry("I can start a call to $number after you confirm it.")
                speak("I can start the call after you confirm")
                showCallConfirmation(vm, number)
            }
            lower.startsWith("message ") || lower.startsWith("text ") -> {
                vm.addUser(text)
                val body = text.substringAfter(' ').trim()
                val intent = Intent(Intent.ACTION_SENDTO).apply { data = Uri.parse("smsto:"); putExtra("sms_body", body) }
                if (intent.resolveActivity(packageManager) != null) startActivity(intent)
                else { vm.addJerry("No messaging app is available."); speak("No messaging app is available") }
            }
            lower.contains("search the web") || lower.startsWith("search ") -> {
                val query = text.substringAfter("search", "").trim()
                vm.addUser(text)
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(query)))
                startActivity(intent)
                vm.addJerry("Searching the web for $query.")
                speak("Searching the web")
            }
            else -> {
                if (apiKey.isBlank()) {
                    vm.addUser(text)
                    vm.addJerry("Add your Gemini API key in Jerry Settings first.")
                    speak("Please add your Gemini API key in Jerry Settings")
                } else vm.askGemini(apiKey, text) { speak(it) }
            }
        }
    }

    private fun showCallConfirmation(vm: JerryViewModel, number: String) {
        val dialog = AlertDialog.Builder(this)
            .setTitle("Confirm call")
            .setMessage("Call $number?")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Call") { _, _ ->
                val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(number)))
                startActivity(intent)
            }
            .create()
        dialog.show()
    }

    private fun speak(text: String) { tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jerry") }

    override fun onInit(status: Int) { if (status == TextToSpeech.SUCCESS) tts?.language = Locale.getDefault() }

    override fun onDestroy() {
        recognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
