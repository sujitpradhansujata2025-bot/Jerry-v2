# Jerry — Android AI Assistant

A starter Android voice assistant using Kotlin, Jetpack Compose, Android SpeechRecognizer/TextToSpeech, and the Gemini Interactions API.

## Build

Open this folder in Android Studio and let Gradle sync.

## Gemini key

Open Jerry > Settings and enter a Gemini API key for local testing.

IMPORTANT: this starter stores the key only in the running app's memory. For a production/distributed app, move Gemini calls behind a secure server or use an architecture that does not expose a permanent private key in the APK.

## Current scope

- Voice input
- Gemini 3.8 Flash text assistant
- Spoken responses
- Chat history for the current session
- Dark Jerry UI
- Permission/error handling

## Next upgrades

- Controlled Gemini function calling
- App launching
- Alarm/timer actions
- Contact/call actions with confirmation
- Default digital assistant integration
- Secure backend
- Wake-word support where Android permits it