# Jerry v3 GitHub build

This version fixes the Java/Kotlin JVM target mismatch by compiling both against Java 17.

GitHub Actions should:
1. Checkout the repository.
2. Extract `JerryAssistant-v3.zip`.
3. Use JDK 17.
4. Use Gradle 8.13.
5. Run `gradle assembleDebug` from the extracted `JerryAssistant` directory.
6. Upload `app/build/outputs/apk/debug/app-debug.apk` as an artifact.
