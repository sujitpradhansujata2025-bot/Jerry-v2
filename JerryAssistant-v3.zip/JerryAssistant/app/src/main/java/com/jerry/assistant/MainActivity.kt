package com.jerry.assistant

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.speech.*
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.*
import okhttp3.*
import org.json.JSONObject
import java.util.Locale

data class Chat(val who: String, val text: String)

class JerryViewModel : ViewModel() {
    var messages by mutableStateOf(listOf(Chat("Jerry", "Hi! I'm Jerry. Tap the microphone and tell me what you need.")))
        private set
    var listening by mutableStateOf(false)
    var thinking by mutableStateOf(false)

    fun addUser(text: String) { messages = messages + Chat("You", text) }
    fun addJerry(text: String) { messages = messages + Chat("Jerry", text) }

    fun askGemini(apiKey: String, prompt: String, onDone: (String) -> Unit) {
        thinking = true
        addUser(prompt)
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val body = JSONObject()
                    .put("model", "gemini-3.8-flash")
                    .put("store", false)
                    .put("system_instruction", "You are Jerry, a concise and friendly Android voice assistant. Answer naturally. If the user asks you to perform an action, explain the action briefly; the Android app may execute only explicitly supported actions.")
                    .put("input", prompt)
                    .toString()

                val request = Request.Builder()
                    .url("https://generativelanguage.googleapis.com/v1beta/interactions")
                    .addHeader("x-goog-api-key", apiKey)
                    .addHeader("Content-Type", "application/json")
                    .post(body.toRequestBody("application/json".toMediaType()))
                    .build()

                OkHttpClient().newCall(request).execute().use { response ->
                    if (!response.isSuccessful) throw Exception("Gemini HTTP ${response.code}")
                    val json = JSONObject(response.body?.string() ?: "{}")
                    val steps = json.optJSONArray("steps")
                    var answer = ""
                    if (steps != null) {
                        for (i in 0 until steps.length()) {
                            val step = steps.getJSONObject(i)
                            if (step.optString("type") == "model_output") {
                                val content = step.optJSONArray("content")
                                if (content != null) {
                                    for (j in 0 until content.length()) {
                                        val c = content.getJSONObject(j)
                                        if (c.optString("type") == "text") answer += c.optString("text")
                                    }
                                }
                            }
                        }
                    }
                    if (answer.isBlank()) answer = "I couldn't generate a response."
                    withContext(Dispatchers.Main) {
                        thinking = false
                        addJerry(answer)
                        onDone(answer)
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    thinking = false
                    val msg = "Sorry, I couldn't connect to Gemini."
                    addJerry(msg)
                    onDone(msg)
                }
            }
        }
    }
}

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var recognizer: SpeechRecognizer? = null
    private var apiKey by mutableStateOf("")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        setContent { JerryApp() }
    }

    @Composable
    fun JerryApp(vm: JerryViewModel = viewModel()) {
        var key by remember { mutableStateOf("") }
        var showSettings by remember { mutableStateOf(false) }

        val micPermission = rememberLauncherForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) { }

        MaterialTheme(colorScheme = darkColorScheme()) {
            Surface(Modifier.fillMaxSize(), color = Color(0xFF070A12)) {
                if (showSettings) {
                    Column(Modifier.padding(24.dp)) {
                        Text("Jerry Settings", style = MaterialTheme.typography.headlineMedium)
                        Spacer(Modifier.height(20.dp))
                        OutlinedTextField(
                            value = key,
                            onValueChange = { key = it; apiKey = it },
                            label = { Text("Gemini API key") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(Modifier.height(12.dp))
                        Text("For a production app, don't embed a permanent private API key in a distributed APK.")
                        Spacer(Modifier.height(20.dp))
                        Button(onClick = { showSettings = false }) { Text("Done") }
                    }
                } else {
                    Column(Modifier.fillMaxSize().padding(16.dp)) {
                        Text("JERRY", style = MaterialTheme.typography.headlineLarge)
                        Text(if (vm.listening) "Listening..." else if (vm.thinking) "Thinking..." else "Your personal AI assistant")
                        Spacer(Modifier.height(12.dp))

                        LazyColumn(Modifier.weight(1f), reverseLayout = true) {
                            items(vm.messages.reversed()) { chat ->
                                Text(
                                    "${chat.who}: ${chat.text}",
                                    modifier = Modifier.padding(vertical = 8.dp)
                                )
                            }
                        }

                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Button(onClick = { showSettings = true }) { Text("Settings") }
                            FloatingActionButton(
                                onClick = {
                                    if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                                        micPermission.launch(Manifest.permission.RECORD_AUDIO)
                                    } else {
                                        startListening(vm)
                                    }
                                },
                                shape = CircleShape
                            ) { Text("🎙") }
                        }
                    }
                }
            }
        }
    }

    private fun startListening(vm: JerryViewModel) {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            vm.addJerry("Speech recognition is not available on this phone.")
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { vm.listening = true }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() { vm.listening = false }
                override fun onError(error: Int) {
                    vm.listening = false
                    vm.addJerry("I couldn't hear you. Please try again.")
                }
                override fun onResults(results: Bundle?) {
                    vm.listening = false
                    val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (!text.isNullOrBlank()) {
                        if (apiKey.isBlank()) {
                            vm.addUser(text)
                            vm.addJerry("Add your Gemini API key in Jerry Settings first.")
                            speak("Please add your Gemini API key in Jerry Settings.")
                        } else {
                            vm.askGemini(apiKey, text) { speak(it) }
                        }
                    }
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            }
            startListening(intent)
        }
    }

    private fun speak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jerry")
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts?.language = Locale.getDefault()
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}